package com.ss.board.it.dto;

// 개발팀
public class DevelopmentTeam extends Department{
}
