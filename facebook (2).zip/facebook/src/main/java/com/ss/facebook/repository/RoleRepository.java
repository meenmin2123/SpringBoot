package com.ss.facebook.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.ss.facebook.entity.Role;

public interface RoleRepository 
		extends JpaRepository<Role, Long>{

}
