package com.ss.facebook.entity;

import java.util.Set;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Data
@EqualsAndHashCode(of ="id")
@AllArgsConstructor
@NoArgsConstructor
@RequiredArgsConstructor
@Entity
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType
								.IDENTITY)
	private Long id;
	
	@NonNull
	@Column(nullable = false)
	private String email;
	
	@NonNull
	@Column(nullable = false)
	private String name;
	
	@NonNull
	private String provider; // 회사명
	@NonNull
	private String providerId; // 회사명기준으로 고유한 id
	
	
	// Role엔티티에 있는 user필드 뜻!
	// Role엔티티에 user라는 필드가 외래키를
	// 관리하고 있다. 이렇게 하면 양방향 
	// 매핑 
	@OneToMany(mappedBy = "user"
			,cascade = CascadeType.ALL
			,fetch = FetchType.EAGER)
	private Set<Role> roles;
	
	
	
	
	
	
}
