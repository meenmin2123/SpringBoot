package com.ss.facebook.service;

import org.springframework.stereotype.Service;

@Service
public class FackBookService {
		
}
