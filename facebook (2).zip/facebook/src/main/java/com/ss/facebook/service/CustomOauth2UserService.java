package com.ss.facebook.service;

import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

import com.ss.facebook.entity.Role;
import com.ss.facebook.entity.User;
import com.ss.facebook.repository.UserRepository;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Service
public class CustomOauth2UserService 
				extends DefaultOAuth2UserService{
	
	@Autowired
	private UserRepository repository;
	
	
	@Override   // Oauth2 로그인 요청이 들어왔을 때 사용자의 인증 정보를
				// 가져오는 역할을 한다. 
	public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {
		
		log.info("loadUser실행!"); // AOP 변경
		OAuth2User oauth = super.loadUser(userRequest);
		
		//회사 정보를 출력하기 
		String provider = userRequest
				         .getClientRegistration()
				         .getRegistrationId();
		System.out.println("회사명:" + provider);
		System.out.println("userRequest: " + oauth);
		System.out.println("id:" +
						  oauth.getAttribute("id"));
		System.out.println("email:" +
				  	 oauth.getAttribute("email"));

		// 사용자 정보가 DB에 있는지 확인 
		User temp = repository.findByEmail(oauth.getAttribute("email"));
		
		System.out.println("user결과:"+ temp);
		
		Set<Role> roles = new HashSet<Role>();
		User user = null;
		
		// 회원이 아니라 뜻! 가입먼저 시킴!
		if(temp == null) {
			// 고유한 id값을 이용해서 각각 간편로그인을 했을 때
			// 충돌 되지 않도록 회사명_id
			
			String id = oauth.getAttribute("id");
			String providerId = provider + "_"+id;
			
			String email = oauth.getAttribute("email");
			String name = oauth.getAttribute("name");
			// 새로운 객체(사용자 등록)
			user = new User(email, name,
								 provider, providerId);
			
			// 기본 권한 설정
			Role userRole = new Role();
			userRole.setName("ROLE_USER");
			userRole.setUser(user);
			
			user.setRoles(roles);
			repository.save(user);			
			// 새로 저장된 사용자의 권한을 roles 에 저장해서
			// 시큐리티 세션에 들어갈 수있도록 권한을 넘겨준다. 
			// Oauth2User객체를 생성할 때 넘겨준다.
			roles.add(userRole);
		}else {
			// 이미 회원가입이 된 상태 DB에 저장된 권한만
			// 가져오기
			user = temp; 
			roles = user.getRoles();			
		}
		
		// 사용자 정보와 권한을 전달!
		return new CustomOauth2User(oauth,roles);
	}
}
