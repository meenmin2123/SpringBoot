package com.ss.facebook.service;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.oauth2.core.user.OAuth2User;

import com.ss.facebook.entity.Role;

public class CustomOauth2User implements OAuth2User {

	private OAuth2User oauth2User;
	private Set<Role> roles; 
	
	public CustomOauth2User(OAuth2User oauth2User,
							Set<Role> roles) {
		this.oauth2User = oauth2User;
		this.roles = roles; //권한을 받아서 설정만!		
	}
	
	
	@Override
	public Map<String, Object> getAttributes() {
		// TODO Auto-generated method stub
		return oauth2User.getAttributes();
		// 인증서버에서 받아온 사용자 정보를 Map형식으로 반환
		// {"email" : "em@g.c","name":"seohee"}
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		// 권한 결과를 담을 Set을 생성함 
		Set<GrantedAuthority> auth = 
				new HashSet<GrantedAuthority>();
		
		for(Role role : roles) {
			auth.add(new SimpleGrantedAuthority
							(role.getName()));
		}		
		
		return auth;
	}

	@Override
	public String getName() {
		// TODO Auto-generated method stub
		return oauth2User.getName();
	}

}
