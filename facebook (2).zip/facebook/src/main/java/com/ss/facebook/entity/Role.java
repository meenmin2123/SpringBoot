package com.ss.facebook.entity;

import javax.persistence.*;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

@EqualsAndHashCode(of="id")
@NoArgsConstructor
@AllArgsConstructor
@Data
@Entity
public class Role {
	@Id
	@GeneratedValue(strategy = GenerationType
								.IDENTITY)
	private Long id;
	
	@Column(nullable = false)
	private String name; 
	
	//user테이블과 연결 (조인)
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name="user_id")
	private User user;
	

}
