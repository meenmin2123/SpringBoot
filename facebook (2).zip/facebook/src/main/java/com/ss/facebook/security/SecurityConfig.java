package com.ss.facebook.security;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;

import com.ss.facebook.service.CustomOauth2UserService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Configuration
public class SecurityConfig {
	
	//실제 Oauth2로 사용자 정보 처리를 하는
	// 서비스 객체 생성 
	private final CustomOauth2UserService
				  customService;
	// 생성자 주입 방식
	public SecurityConfig(CustomOauth2UserService cu) {
		log.info("SecurityConfig 생성자 실행!");
		customService = cu;
	}
	
	@Bean //시큐리티 보안 설정 후
		  //SecurityFilterChain타입으로 객체 생성
	public SecurityFilterChain filter(HttpSecurity http) throws Exception {
		
		http
			.csrf().disable()
			.cors().and()
			.authorizeHttpRequests()
			.antMatchers("/index")
			.permitAll()
			.anyRequest().authenticated()
			.and()
			.oauth2Login()
			.loginPage("/index")
			.userInfoEndpoint() //로그인한 사용자의 정보를 받아올 준비
			.userService(customService)
			.and()
			.successHandler(successHandler())
			.failureHandler(failureHandler());
		
		return http.build();
		
	}	
	
	//실패시
	private AuthenticationFailureHandler 
							failureHandler() {
		return new AuthenticationFailureHandler() {
			
			@Override
			public void onAuthenticationFailure(HttpServletRequest request,
											HttpServletResponse response,
					AuthenticationException exception) throws IOException, ServletException {
				response.sendRedirect("/login-fail");
			}
		};
	}
	//성공시
	private AuthenticationSuccessHandler 
							successHandler() {
		return new AuthenticationSuccessHandler() {
			
			@Override
			public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response,
					Authentication authentication) throws IOException, ServletException {
				response.sendRedirect("/login-success");
			}
		};
	}

	// AuthenticationManager
	// 스프링 시큐리티에서 사용자 인증을 담당하는 인터페이스!
	// 사용자 자격증명확인하는 역할 
	@Bean
    public AuthenticationManager authenticationManager
    (AuthenticationConfiguration configuration) throws Exception {
    	System.out.println("인증권한 매니저 생성!");
        return configuration.
        		getAuthenticationManager();
        	 // AuthenticationManager 빈 등록
    }
    
	// 스프링시큐리티는 암호화를 해서 디비에 저장하지 않으면
	// 로그인 자체가 안된다.!
    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(); // 비밀번호 암호화 방식 설정
    }
}
