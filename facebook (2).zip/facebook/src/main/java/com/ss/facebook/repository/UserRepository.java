package com.ss.facebook.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ss.facebook.entity.User;

public interface UserRepository 
			extends JpaRepository<User, Long>{
	
	// 이메일로 검색 
	User findByEmail(String email);
	
}
