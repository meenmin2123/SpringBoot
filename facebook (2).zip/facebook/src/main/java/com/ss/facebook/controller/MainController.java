package com.ss.facebook.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import com.ss.facebook.service.FackBookService;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class MainController {

	@Autowired
	private FackBookService service;
	
	@GetMapping("/index")
	public String index() {
		log.info("index페이지실행!");
		return "index";
	}
	@GetMapping("/login-success")
	public String login_success() {
		log.info("index페이지실행!");
		return "login-success";
	}
	
	@GetMapping("/login-fail")
	public String login_fail() {
		log.info("index페이지실행!");
		return "login-fail";
	}
	
	
}
