package com.ss.thymybatis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymybatisApplicationTests {

	@Test
	void contextLoads() {
	}

}
